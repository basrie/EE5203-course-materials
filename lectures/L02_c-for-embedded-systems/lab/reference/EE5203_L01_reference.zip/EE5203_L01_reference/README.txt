EE5203 - Lab 1 reference project (NUCLEO-F401RE, STM32CubeMX 6.18 CMake project)

Use this only if your own EE5203_L01_<studentnumber> project does not build.

1. Unzip into C:\Work\<studentnumber>. You get the folder EE5203_L01_reference.
2. Do Lab 2 Checkpoint A with this folder in place of your L01 folder:
   copy it, rename the copy EE5203_L02_<studentnumber>, delete the build folder,
   and change CMAKE_PROJECT_NAME in CMakeLists.txt to the new folder name.
3. Build with Ctrl+Shift+B. Flash with F5: LD2 blinks every 500 ms.

Contents: board defaults from CubeMX (PA5 = LD2 output), the Lab 1 blink code
in main.c (USER CODE 2 and 3), and the lab .vscode folder.
